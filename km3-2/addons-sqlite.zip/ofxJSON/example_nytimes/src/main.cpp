#include "ofApp.h"

int main()
{
    ofSetupOpenGL(800, 700, OF_WINDOW);
    ofRunApp(new ofApp());
}
